#!/bin/bash
python=/opt/software/Anaconda/Anaconda3/bin/python3.8


$python select_SNPs_in_db.py      #select the SNPs required for the gene expression prediction model (SNPs in the db database)

plink --cow --file ./Input_file/genotypes --extract ./Output_file/combined_SNPs_in_gene.txt --recode --out ./Output_file/selected_SNPs

plink --cow --file ./Output_file/selected_SNPs --recodeA --out ./Output_file/selected_SNPs

rm ./Output_file/selected_SNPs.nosex ./Output_file/selected_SNPs.log
