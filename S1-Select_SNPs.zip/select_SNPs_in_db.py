# -*- coding: utf-8 -*-
import sqlite3

def extract_snps(db_file, gene):
    conn = sqlite3.connect(db_file)
    cur = conn.cursor()
    
    # Execute the query
    cur.execute("SELECT rsid FROM weights WHERE gene=?", (gene,))
    
    # Fetch all the results
    results = cur.fetchall()
    
    # Close the connection
    conn.close()
    
    # Extract the rsids from the results
    rsids = [result[0] for result in results]

    return rsids

db_file = './Input_file/gtex_v1_Blood_imputed_Bos_signif.db'

# Load the genes from the file
with open('./Input_file/selected_genes.txt', 'r') as f:
    genes = [line.strip() for line in f]

# Initialize an empty set to store unique SNPs
all_snps = set()

# Open the SNPs_in_model.txt file
with open('./Output_file/SNPs_in_gene.txt', 'w') as f:
    # For each gene, extract the SNPs and add them to the set
    for gene in genes:
        snps = extract_snps(db_file, gene)
        all_snps.update(snps)
        # Write the SNPs to the SNPs_in_model.txt file
        for snp in snps:
            f.write(gene + "\t" + snp + "\n")

# Open the combined_SNPs.txt file
with open('./Output_file/combined_SNPs_in_gene.txt', 'w') as f:
    # Write each unique SNP to the file
    for snp in all_snps:
        f.write(snp + "\n")
